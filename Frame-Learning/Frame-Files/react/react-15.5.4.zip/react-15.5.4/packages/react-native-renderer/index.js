'use strict';

module.exports = require('./lib/ReactNative');

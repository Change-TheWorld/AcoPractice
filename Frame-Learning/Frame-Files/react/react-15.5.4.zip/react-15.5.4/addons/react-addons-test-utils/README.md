# react-addons-test-utils

This package provides the React TestUtils add-on.

See <https://facebook.github.io/react/docs/test-utils.html> for more information.

This package is deprecated as of version 15.5.0:
* TestUtils have been moved to `react-dom/test-utils`
* Shallow renderer has been moved to `react-test-renderer/shallow`
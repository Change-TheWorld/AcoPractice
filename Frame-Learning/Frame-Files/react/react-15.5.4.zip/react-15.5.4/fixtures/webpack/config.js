module.exports = {
  entry: './input',
  output: {
    filename: 'output.js',
  },
  resolve: {
    root: '../../build/packages',
  },
};

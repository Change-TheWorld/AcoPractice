System.config({
  paths: {
    react: '../../build/react-with-addons.js',
    'react-dom': '../../build/react-dom.js',
  },
});
